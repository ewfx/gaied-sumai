import streamlit as st
import os
import fitz  # PyMuPDF
import datetime
import easyocr
from PIL import Image
import cv2
import json 
import openai
import time

# Define the PDF-to-images function
def pdf_to_images(pdf_path, output_folder=r"E:\Venv\babu_email_classification\email_classification_AI\images"):
    doc = fitz.open(pdf_path)
    images = []
    pdf_filename = os.path.splitext(os.path.basename(pdf_path))[0]  
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    for page_num in range(len(doc)):
        pix = doc[page_num].get_pixmap()
        image_path = f"{output_folder}/{pdf_filename}_page_{page_num + 1}_{timestamp}.png"
        pix.save(image_path)
        images.append(image_path)
    doc.close()
    return images  # List of image file paths

# Define the text extraction function
def extract_text_from_image(image_path):
    """
    Detects text in an image file using EasyOCR.
    :param image_path: Path to the image file (e.g., .jpg, .png).
    :return: Extracted text as a string.
    """
    try:
        image = Image.open(image_path)
        img = cv2.imread(image_path)
        print("ocr started ")
        # Initialize the EasyOCR reader for English
        reader = easyocr.Reader(['en'], gpu=False, verbose=False)
     
        # Use EasyOCR to extract text from the image
        extracted_text = reader.readtext(img, detail=0)
        print("ocr completed ")

        # Combine the text into a single string
        return " ".join(extracted_text)
    except Exception as e:
        return st.write(f"Error: {str(e)}")
    
# Define the JSON dataset loading function
def load_reference_dataset(json_file_path):
    with open(json_file_path, "r") as file:
        dataset = json.load(file)
    return dataset

def gpt_based_classification(email_text, reference_data):
    api_key="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"
    client = openai.OpenAI(api_key=api_key)  # Initialize the client
    print("prompting  started ")

    # Prepare the prompt
    prompt = f"""
    You are an expert in email classification and structured data extraction. Your tasks:
    
    1. **Classify the email** into a Request Type and Sub-Request Type based on the provided reference dataset.
    2. **Extract structured details** from the email if available:
        - **Date** (format: YYYY-MM-DD or DD/MM/YYYY)
        - **Amount** (monetary values with currency symbols or numerals)
        - **Dealer Name** (company or individual mentioned as a dealer or seller)
    
    Reference Dataset for Classification:
    {json.dumps(reference_data, indent=4)}

    Email Content:
    {email_text}

    Provide the response in JSON format:
    {{
        "RequestType": "Classified Request Type",
        "SubRequestType": "Classified Sub-Request Type",
        "Reasoning": "Brief explanation for classification",
        "ExtractedDetails": {{
            "Date": "YYYY-MM-DD",
            "Amount": "123.45",
            "Dealer_Name": "XYZ Dealer"
        }}
    }}
    )
    """
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7
    )
    result = response.choices[0].message.content 
    print("prompting  completed ")
    return json.loads(result)

# Streamlit App
def main():
    st.title("Streamlit App with PDF-to-Text Extraction")

    # Hard-coded directory path
    hard_coded_directory = r"E:\Venv\babu_email_classification\email_classification_AI\data\emails"
    # Path to the JSON file
    json_file_path = r"E:\Venv\babu_email_classification\email_classification_AI\data\Email_datasets\referancedata.json"
     # Load the reference data
    reference_data = None
    try:
        reference_data = load_reference_dataset(json_file_path)
        #st.write("### Reference Dataset Loaded:")
        #st.json(reference_data)  # Display the loaded JSON data
    except Exception as e:
        st.error(f"Error loading reference dataset: {e}")
    # Dropdown for files in the hard-coded directory
    try:
        # Fetch list of files in the directory
        file_list = [f for f in os.listdir(hard_coded_directory) if os.path.isfile(os.path.join(hard_coded_directory, f))]
        selected_file = st.selectbox("Select a PDF file from the directory:", file_list)

        # Display selected file and process it
        if selected_file:
            file_path = os.path.join(hard_coded_directory, selected_file)
            pdf_filename = os.path.splitext(os.path.basename(file_path))[0]  
            st.write(f"You selected: {pdf_filename}")

            # Button to process the selected PDF file
            if st.button("Classify Email"):
                try:
                    output_images = pdf_to_images(file_path)  # Call the function
            
   
                    for image in output_images:
                        st.write("Images successfully created!")

                    # Extract text from images and combine results
                    email_text = ""
                    for image_path in output_images:
                        extracted_text = extract_text_from_image(image_path)  # Extract text from each image
                        email_text += extracted_text + "\n"

                    st.write("### Step 2: Extracted Text from Images")
                    #st.text_area("Extracted Email Text:", email_text, height=300)
                    
                    # Step 3: Classify email using GPT
                    if reference_data is not None:
                        classification_result = gpt_based_classification(email_text, reference_data)
                        st.write("### Step 3: Classification Result")
                        #st.json(classification_result)
                        st.text_area("Email Classification:", classification_result, height=300)

                        time.sleep(3)  # Wait for 15 seconds

                        if st.button("Restart"):
                            st.experimental_rerun()  # Refresh the Streamlit app

                    else:
                        st.error("Reference dataset is not loaded. Please check the JSON file.")

                except Exception as e:
                    st.error(f"An error occurred while processing the PDF: {e}")
    except FileNotFoundError:
        st.error("Directory not found. Please check the hard-coded path.")
    except Exception as e:
        st.error(f"An error occurred: {e}")

if __name__ == "__main__":
    main()
