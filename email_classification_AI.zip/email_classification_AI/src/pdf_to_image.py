import fitz  # PyMuPDF
import datetime

def pdf_to_images(pdf_path, output_folder="images"):
    doc = fitz.open(pdf_path)
    images = []
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    for page_num in range(len(doc)):
        pix = doc[page_num].get_pixmap()
        image_path = f"{output_folder}/page_{page_num + 1}_{timestamp}.png"
        pix.save(image_path)
        images.append(image_path)
    doc.close()
    return images  # List of image file paths